﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
namespace Clothes
{
    public class DBConnector
    {
        public DBConnector(String server, String database, String port, String uid, String password)
        {
            String connectionString;
            connectionString = "SERVER=" + server + ";" + "PORT=" + port + ";DATABASE=" +
                                 database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";";
            connection = new MySqlConnection(connectionString);
            connection.Open();
        }
        ~DBConnector() 
        {
            connection.Close();
        }

        public List<ClothStruct> SelectClothByCriteria(String clothtype) // возвращает пути к одежде данного типа
        {
            String query = "SELECT * from clothdata where name='" + clothtype + "';";
            MySqlCommand cmd = new MySqlCommand(query, connection);
            MySqlDataReader reader = cmd.ExecuteReader();
            List<ClothStruct> res = new List<ClothStruct>();
            while (reader.Read())
            {
                ClothStruct newCloth = new ClothStruct();
                newCloth.Path = reader["path"] + "";
                newCloth.Cost = Convert.ToDouble(reader["price"] + "");
                newCloth.Style = reader["name"] + "";
                res.Add(newCloth);
            }
            reader.Close();
            return res;
        }
        private MySqlConnection connection;
    }
}
