﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Clothes;
namespace Clothes
{
    public partial class formEmail : Form
    {
        public formEmail()
        {
            InitializeComponent();
        }

        private void formEmail_Load(object sender, EventArgs e)
        {
            txtUrEmail.Text = frmMain.dataManager.GetEmailFrom();
            txtPassword.Text = frmMain.dataManager.GetPassword();
            txtSmtpServer.Text = frmMain.dataManager.GetSmtpServer();
            txtSubject.Text = frmMain.dataManager.GetSubject();
            txtLetterText.Text = frmMain.dataManager.GetMessageText();
        }

        private void btnSaveChanges_Click(object sender, EventArgs e)
        {
            frmMain.dataManager.SetEmailFrom(txtUrEmail.Text);
            frmMain.dataManager.SetPassword(txtPassword.Text);
            frmMain.dataManager.SetSmtpServer(txtSmtpServer.Text);
            frmMain.dataManager.SetSubject(txtSubject.Text);
            frmMain.dataManager.SetMessageText(txtLetterText.Text);
            this.Close();
        }
    }
}
