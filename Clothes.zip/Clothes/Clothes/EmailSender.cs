﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clothes
{
    class EmailSender
    {
        public EmailSender() // данные для посылки email берутся из frmMain.dataManager, который хранит данные для ящика, с которого будет проводиться рассылка
        {
        }
        public void SendToEmail()
        {
        }
    }
}
