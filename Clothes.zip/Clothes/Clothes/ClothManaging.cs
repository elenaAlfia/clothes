﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clothes
{

    public struct ClothStruct
    {
        public String Name;
        public String Type;
        public Double Cost;
        public String Size;
        public String Path;
        public String Style;
    }
}
