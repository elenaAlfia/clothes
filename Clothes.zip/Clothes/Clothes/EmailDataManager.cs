﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clothes
{
    public class EmailDataManager
    {
        private String NameFrom;
        public void SetNameFrom(String newName) { NameFrom = newName; }
        public String GetNameFrom() { return NameFrom; }
        private String EmailFrom;
        public void SetEmailFrom(String newName) { EmailFrom = newName; }
        public String GetEmailFrom() { return EmailFrom; }
        private String SmtpServer;
        public void SetSmtpServer(String newName) { SmtpServer = newName; }
        public String GetSmtpServer() { return SmtpServer; }
        private String Password;
        public void SetPassword(String newName) { Password = newName; }
        public String GetPassword() { return Password; }
        private String Subject;
        public void SetSubject(String newName) { Subject = newName; }
        public String GetSubject() { return Subject; }
        private String MessageText;
        public void SetMessageText(String newName) { MessageText = newName; }
        public String GetMessageText() { return MessageText; }
    }
}
