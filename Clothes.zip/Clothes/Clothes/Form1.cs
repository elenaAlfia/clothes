﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Entity;
using MySql.Data.Types;
using MySql.Data.Common;
using Clothes;
using Microsoft.Office.Interop;

// В качестве сервера баз данных используется MySQL Server


namespace Clothes
{
    public partial class frmMain : Form // Собственно, класс, который отвечает за загрузку и отображение формы. 
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Word.Application winword = new Microsoft.Office.Interop.Word.Application(); // запуск ms word в фоне для автоматического создания документа
            winword.Visible = true;
            object missing = System.Reflection.Missing.Value;
//            winword.Quit(ref missing, ref missing, ref missing);
//            winword = null;
            
        }
        public static EmailDataManager dataManager = new EmailDataManager();
        public DBConnector dbConnector = new DBConnector("localhost", "clothes", "3309", "root", "132654hwrt");
        private void btnEmailSettings_Click(object sender, EventArgs e)
        {
            formEmail frmE = new formEmail();
            frmE.ShowDialog();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void cbClothSize_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void cmbStyle_SelectedIndexChanged(object sender, EventArgs e)
        {
            Random random = new Random();
            String txt = cmbStyle.Text;
            List<ClothStruct> lst = new List<ClothStruct>();
            if (txt.Equals("Спортивный"))
            {
                lst = dbConnector.SelectClothByCriteria("sport");
            }
            if (txt.Equals("Деловой"))
            {
                lst = dbConnector.SelectClothByCriteria("office");
            }
            if (txt.Equals("Повседневный"))
            {
                lst = dbConnector.SelectClothByCriteria("casual");
            }
            pictureBox1.Image = Image.FromFile(lst[random.Next(0, lst.Count)].Path);
            pictureBox1.Refresh();
        }
    }
}
